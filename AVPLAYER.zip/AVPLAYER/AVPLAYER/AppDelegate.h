//
//  AppDelegate.h
//  AVPLAYER
//
//  Created by 胡杨林 on 2018/1/15.
//  Copyright © 2018年 胡杨林. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

